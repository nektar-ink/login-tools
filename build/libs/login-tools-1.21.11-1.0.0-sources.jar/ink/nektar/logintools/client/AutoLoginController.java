package ink.nektar.logintools.client;

import ink.nektar.logintools.LoginTools;
import ink.nektar.logintools.config.LoginToolsConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_642;
import org.lwjgl.glfw.GLFW;

public final class AutoLoginController {
    private static final int LOGIN_DELAY_TICKS = 40;

    private static int pendingTicks = -1;
    private static String pendingPassword;
    private static String pendingAddress;
    private static LoginToolsConfig.AutoLoginMode pendingMode;
    private static boolean awaitingAskDecision;
    private static boolean yWasDown;
    private static boolean nWasDown;

    private AutoLoginController() {
    }

    public static void handleJoin(class_310 client) {
        clearPending();

        class_642 server = client.method_1558();
        if (server == null) {
            return;
        }

        LoginToolsConfig config = LoginTools.getConfig();
        if (config.autoLoginMode() == LoginToolsConfig.AutoLoginMode.NO) {
            return;
        }

        String password = config.findPasswordForServer(server.field_3761);
        if (password == null || password.isBlank()) {
            return;
        }

        pendingTicks = LOGIN_DELAY_TICKS;
        pendingPassword = password;
        pendingAddress = server.field_3761;
        pendingMode = config.autoLoginMode();
    }

    public static void tick(class_310 client) {
        if (pendingTicks < 0 || client.field_1724 == null) {
            return;
        }

        if (pendingTicks > 0) {
            pendingTicks--;
            return;
        }

        if (pendingMode == LoginToolsConfig.AutoLoginMode.YES) {
            sendLogin(client);
            clearPending();
            return;
        }

        if (!awaitingAskDecision) {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("Use password (" + LoginTools.maskPassword(pendingPassword) + ")? Y/N"), false);
            }
            awaitingAskDecision = true;
        }

        if (client.field_1755 != null) {
            return;
        }

        boolean yDown = class_3675.method_15987(client.method_22683(), GLFW.GLFW_KEY_Y);
        boolean nDown = class_3675.method_15987(client.method_22683(), GLFW.GLFW_KEY_N);

        if (yDown && !yWasDown) {
            sendLogin(client);
            clearPending();
            return;
        }

        if (nDown && !nWasDown) {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("Auto login cancelled for " + pendingAddress + "."), false);
            }
            clearPending();
            return;
        }

        yWasDown = yDown;
        nWasDown = nDown;
    }

    public static void clearPending() {
        pendingTicks = -1;
        pendingPassword = null;
        pendingAddress = null;
        pendingMode = null;
        awaitingAskDecision = false;
        yWasDown = false;
        nWasDown = false;
    }

    private static void sendLogin(class_310 client) {
        sendLogin(client, pendingPassword);
    }

    private static void sendLogin(class_310 client, String password) {
        if (client.field_1724 != null && password != null && !password.isBlank()) {
            client.field_1724.field_3944.method_45730("login " + password);
        }
    }
}
