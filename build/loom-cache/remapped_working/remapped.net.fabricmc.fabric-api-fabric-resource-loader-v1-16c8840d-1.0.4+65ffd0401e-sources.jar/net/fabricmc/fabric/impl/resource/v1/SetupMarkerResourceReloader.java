/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.resource.v1;

import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.SynchronousResourceReloader;
import net.minecraft.resource.featuretoggle.FeatureSet;

// Used to inject into the ResourceReloader store.
public record SetupMarkerResourceReloader(RegistryWrapper.WrapperLookup registryLookup, FeatureSet featureSet) implements SynchronousResourceReloader {
	@Override
	public void prepareSharedState(Store store) {
		store.put(ResourceLoader.RELOADER_REGISTRY_LOOKUP_KEY, registryLookup);
		store.put(ResourceLoader.RELOADER_FEATURE_SET_KEY, featureSet);
	}

	@Override
	public void reload(ResourceManager manager) {
		// Do nothing.
	}
}
