package ink.nektar.logintools.mixin;

import ink.nektar.logintools.LoginTools;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_408.class)
public abstract class ChatScreenMixin {
    @Shadow
    protected class_342 chatField;

    @Inject(method = "render", at = @At("TAIL"))
    private void loginTools$maskLoginPassword(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        String text = this.chatField.method_1882();
        if (!LoginTools.shouldMaskLoginCommand(text)) {
            return;
        }

        String maskedText = LoginTools.maskedLoginText(text);
        int x1 = this.chatField.method_46426() + 2;
        int y1 = this.chatField.method_46427() + 2;
        int x2 = this.chatField.method_46426() + this.chatField.method_25368() - 2;
        int y2 = this.chatField.method_46427() + this.chatField.method_25364() - 2;
        context.method_25294(x1, y1, x2, y2, 0xFF000000);

        int textY = this.chatField.method_46427() + (this.chatField.method_25364() - 8) / 2;
        context.method_27535(class_310.method_1551().field_1772, class_2561.method_43470(maskedText), this.chatField.method_46426() + 4, textY, 0xE0E0E0);
    }
}
