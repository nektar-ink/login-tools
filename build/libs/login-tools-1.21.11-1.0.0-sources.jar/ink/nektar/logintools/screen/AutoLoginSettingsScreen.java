package ink.nektar.logintools.screen;

import ink.nektar.logintools.config.LoginToolsConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

public final class AutoLoginSettingsScreen extends class_437 {
    private final class_437 parent;
    private final LoginToolsConfig workingCopy;
    private final List<RowWidgets> rowWidgets = new ArrayList<>();
    private class_342 globalPasswordField;

    public AutoLoginSettingsScreen(class_437 parent, LoginToolsConfig workingCopy) {
        super(class_2561.method_43470("Auto Login Settings"));
        this.parent = parent;
        this.workingCopy = workingCopy;
    }

    @Override
    protected void method_25426() {
        this.rowWidgets.clear();
        int centerX = this.field_22789 / 2;
        int top = 118;

        this.method_37063(class_4185.method_46430(this.scopeText(), button -> {
            this.workingCopy.setPasswordScope(this.workingCopy.passwordScope().next());
            this.field_22787.method_1507(new AutoLoginSettingsScreen(this.parent, this.workingCopy));
        }).method_46434(centerX - 110, top, 220, 20).method_46431());

        if (this.workingCopy.passwordScope() == LoginToolsConfig.PasswordScope.GLOBAL) {
            this.globalPasswordField = this.method_37063(new class_342(this.field_22793, centerX - 110, 162, 220, 20, class_2561.method_43470("Password for all servers")));
            this.globalPasswordField.method_1880(256);
            this.globalPasswordField.method_1852(this.workingCopy.globalPassword());
            this.globalPasswordField.method_1863(this.workingCopy::setGlobalPassword);
        } else {
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Add server"), button -> {
                this.workingCopy.serverPasswords().add(new LoginToolsConfig.ServerPasswordEntry("", ""));
                this.field_22787.method_1507(new AutoLoginSettingsScreen(this.parent, this.workingCopy));
            }).method_46434(centerX - 110, 154, 220, 20).method_46431());

            int y = 206;
            for (int i = 0; i < this.workingCopy.serverPasswords().size(); i++) {
                LoginToolsConfig.ServerPasswordEntry entry = this.workingCopy.serverPasswords().get(i);
                class_342 addressField = this.method_37063(new class_342(this.field_22793, centerX - 110, y, 106, 20, class_2561.method_43470("address")));
                addressField.method_1880(255);
                addressField.method_1852(entry.address());

                class_342 passwordField = this.method_37063(new class_342(this.field_22793, centerX + 4, y, 76, 20, class_2561.method_43470("password")));
                passwordField.method_1880(255);
                passwordField.method_1852(entry.password());

                int index = i;
                addressField.method_1863(value -> this.updateEntry(index, value, passwordField.method_1882()));
                passwordField.method_1863(value -> this.updateEntry(index, addressField.method_1882(), value));

                class_4185 deleteButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Delete"), button -> {
                    this.workingCopy.serverPasswords().remove(index);
                    this.field_22787.method_1507(new AutoLoginSettingsScreen(this.parent, this.workingCopy));
                }).method_46434(centerX + 88, y, 60, 20).method_46431());

                this.rowWidgets.add(new RowWidgets(addressField, passwordField, deleteButton));
                y += 24;
            }
        }

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> this.method_25419())
            .method_46434(centerX - 100, this.field_22790 - 28, 200, 20).method_46431());
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int centerX = this.field_22789 / 2;
        int panelX = centerX - 138;
        context.method_27534(this.field_22793, this.field_22785, centerX, 20, 0xFFFFFF);
        this.drawPanel(context, panelX, 42, 276, 58, 0xD0140C0C, 0xFFFF5555);
        context.method_27535(this.field_22793, class_2561.method_43470("Password safety warning"), panelX + 12, 52, 0xFFFF8080);
        this.drawWrappedText(context, class_2561.method_43470("Saved passwords stay visible in the local config file. Anyone with access to this computer can read them."), panelX + 12, 68, 252, 0xFFFFFFFF);

        this.drawPanel(context, panelX, 108, 276, this.workingCopy.passwordScope() == LoginToolsConfig.PasswordScope.GLOBAL ? 86 : 64, 0xB0101010, 0xFF3A3A3A);
        context.method_27535(this.field_22793, class_2561.method_43470("Storage mode"), panelX + 12, 118, 0xFFFFFF);
        this.drawWrappedText(context, class_2561.method_43470("Choose one password for every server or save individual passwords for selected addresses."), panelX + 12, 134, 252, 0xA8A8A8);

        if (this.workingCopy.passwordScope() == LoginToolsConfig.PasswordScope.GLOBAL) {
            context.method_27535(this.field_22793, class_2561.method_43470("Password for all servers"), centerX - 110, 150, 0xFFFFFF);
        } else if (this.rowWidgets.isEmpty()) {
            this.drawWrappedText(context, class_2561.method_43470("No saved servers yet. Add a server address and its password below."), centerX - 110, 186, 220, 0xA0A0A0);
        } else {
            context.method_27535(this.field_22793, class_2561.method_43470("Saved server passwords"), centerX - 110, 186, 0xFFFFFF);
        }
    }

    private void drawPanel(class_332 context, int x, int y, int width, int height, int fillColor, int borderColor) {
        context.method_25294(x, y, x + width, y + height, fillColor);
        context.method_25294(x, y, x + width, y + 1, borderColor);
        context.method_25294(x, y + height - 1, x + width, y + height, borderColor);
        context.method_25294(x, y, x + 1, y + height, borderColor);
        context.method_25294(x + width - 1, y, x + width, y + height, borderColor);
    }

    private void drawWrappedText(class_332 context, class_2561 text, int x, int y, int width, int color) {
        int currentY = y;
        for (class_5481 line : this.field_22793.method_1728(text, width)) {
            context.method_35720(this.field_22793, line, x, currentY, color);
            currentY += this.field_22793.field_2000 + 2;
        }
    }

    private class_2561 scopeText() {
        return class_2561.method_43470("Global/Certain : " + this.workingCopy.passwordScope().displayText());
    }

    private void updateEntry(int index, String address, String password) {
        if (index >= 0 && index < this.workingCopy.serverPasswords().size()) {
            this.workingCopy.serverPasswords().set(index, new LoginToolsConfig.ServerPasswordEntry(address, password));
        }
    }

    private record RowWidgets(class_342 addressField, class_342 passwordField, class_4185 deleteButton) {
    }
}
