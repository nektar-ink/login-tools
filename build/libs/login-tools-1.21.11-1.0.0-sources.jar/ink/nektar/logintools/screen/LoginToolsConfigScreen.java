package ink.nektar.logintools.screen;

import ink.nektar.logintools.LoginTools;
import ink.nektar.logintools.config.LoginToolsConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

public final class LoginToolsConfigScreen extends class_437 {
    private final class_437 parent;
    private final LoginToolsConfig workingCopy;

    public LoginToolsConfigScreen(class_437 parent, LoginToolsConfig workingCopy) {
        super(class_2561.method_43470("Login Tools"));
        this.parent = parent;
        this.workingCopy = workingCopy;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int rowWidth = 260;
        int settingsWidth = 34;
        int x = centerX - rowWidth / 2;

        this.method_37063(class_4185.method_46430(this.autoLoginText(), button -> {
            this.workingCopy.setAutoLoginMode(this.workingCopy.autoLoginMode().next());
            button.method_25355(this.autoLoginText());
        }).method_46434(x, 106, rowWidth - settingsWidth - 6, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("..."), button -> this.field_22787.method_1507(new AutoLoginWarningScreen(this, this.workingCopy)))
            .method_46434(x + rowWidth - settingsWidth, 106, settingsWidth, 20).method_46431());

        this.method_37063(class_4185.method_46430(this.hidePasswordText(), button -> {
            this.workingCopy.setHidePassword(!this.workingCopy.hidePassword());
            button.method_25355(this.hidePasswordText());
        }).method_46434(x, 162, rowWidth, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> this.saveAndClose())
            .method_46434(centerX - 102, this.field_22790 - 28, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> this.method_25419())
            .method_46434(centerX + 2, this.field_22790 - 28, 100, 20).method_46431());
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int centerX = this.field_22789 / 2;
        int panelX = centerX - 138;
        this.drawPanel(context, panelX, 48, 276, 154, 0xB0101010, 0xFF3A3A3A);
        context.method_27534(this.field_22793, this.field_22785, centerX, 20, 0xFFFFFF);
        this.drawWrappedText(context, class_2561.method_43470("Manages to protect your passwords."), panelX + 12, 64, 252, 0xB8B8B8);

        context.method_27535(this.field_22793, class_2561.method_43470("Auto Login"), panelX + 12, 92, 0xFFFFFF);
        this.drawWrappedText(context, class_2561.method_43470("Choose whether saved passwords should be sent automatically, confirmed in-world, or never used."), panelX + 12, 132, 214, 0x9F9F9F);

        context.method_27535(this.field_22793, class_2561.method_43470("Hide Password"), panelX + 12, 148, 0xFFFFFF);
        this.drawWrappedText(context, class_2561.method_43470("Masks the visible /login command while you type so the password does not appear on screen."), panelX + 12, 188, 252, 0x9F9F9F);
    }

    private void drawPanel(class_332 context, int x, int y, int width, int height, int fillColor, int borderColor) {
        context.method_25294(x, y, x + width, y + height, fillColor);
        context.method_25294(x, y, x + width, y + 1, borderColor);
        context.method_25294(x, y + height - 1, x + width, y + height, borderColor);
        context.method_25294(x, y, x + 1, y + height, borderColor);
        context.method_25294(x + width - 1, y, x + width, y + height, borderColor);
    }

    private void drawWrappedText(class_332 context, class_2561 text, int x, int y, int width, int color) {
        int currentY = y;
        for (class_5481 line : this.field_22793.method_1728(text, width)) {
            context.method_35720(this.field_22793, line, x, currentY, color);
            currentY += this.field_22793.field_2000 + 2;
        }
    }

    private class_2561 autoLoginText() {
        return class_2561.method_43470("Auto Login : " + this.workingCopy.autoLoginMode().displayText());
    }

    private class_2561 hidePasswordText() {
        return class_2561.method_43470("Hide Password : " + (this.workingCopy.hidePassword() ? "Yes" : "No"));
    }

    private void saveAndClose() {
        LoginTools.setConfig(this.workingCopy.copy());
        LoginTools.saveConfig();
        this.method_25419();
    }
}
