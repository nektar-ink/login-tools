package ink.nektar.logintools.screen;

import ink.nektar.logintools.config.LoginToolsConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

public final class AutoLoginWarningScreen extends class_437 {
    private static final int TIMER_SECONDS = 5;

    private final class_437 parent;
    private final LoginToolsConfig workingCopy;
    private int ticksRemaining = TIMER_SECONDS * 20;
    private class_4185 confirmButton;

    public AutoLoginWarningScreen(class_437 parent, LoginToolsConfig workingCopy) {
        super(class_2561.method_43470("Auto Login Settings"));
        this.parent = parent;
        this.workingCopy = workingCopy;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int panelWidth = 286;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("No, I prefer be safe."), button -> this.method_25419())
            .method_46434(centerX - 116, this.field_22790 - 52, 232, 20).method_46431());

        this.confirmButton = this.method_37063(class_4185.method_46430(this.confirmText(), button -> this.field_22787.method_1507(new AutoLoginSettingsScreen(this.parent, this.workingCopy)))
            .method_46434(centerX - 116, this.field_22790 - 28, 232, 20).method_46431());
        this.confirmButton.field_22763 = false;
    }

    @Override
    public void method_25393() {
        super.method_25393();
        if (this.ticksRemaining > 0) {
            this.ticksRemaining--;
            this.confirmButton.method_25355(this.confirmText());
            if (this.ticksRemaining == 0) {
                this.confirmButton.field_22763 = true;
                this.confirmButton.method_25355(this.confirmText());
            }
        }
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int panelX = this.field_22789 / 2 - 146;
        int panelY = 42;
        int panelWidth = 292;
        int panelHeight = 122;
        int textX = panelX + 14;
        this.drawPanel(context, panelX, panelY, panelWidth, panelHeight, 0xD0140C0C, 0xFFFF5555);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
        context.method_27535(this.field_22793, class_2561.method_43470("Visible warning"), textX, 54, 0xFFFF8080);
        this.drawWrappedText(context, class_2561.method_43470("If someone else brought you to this screen, they may be trying to steal your saved passwords."), textX, 72, 264, 0xFFF0D0D0);
        this.drawWrappedText(context, class_2561.method_43470("Continue only if you understand that passwords are stored locally and can be used automatically."), textX, 114, 264, 0xFFFFFFFF);
    }

    private void drawPanel(class_332 context, int x, int y, int width, int height, int fillColor, int borderColor) {
        context.method_25294(x, y, x + width, y + height, fillColor);
        context.method_25294(x, y, x + width, y + 1, borderColor);
        context.method_25294(x, y + height - 1, x + width, y + height, borderColor);
        context.method_25294(x, y, x + 1, y + height, borderColor);
        context.method_25294(x + width - 1, y, x + width, y + height, borderColor);
    }

    private void drawWrappedText(class_332 context, class_2561 text, int x, int y, int width, int color) {
        int currentY = y;
        for (class_5481 line : this.field_22793.method_1728(text, width)) {
            context.method_35720(this.field_22793, line, x, currentY, color);
            currentY += this.field_22793.field_2000 + 2;
        }
    }

    private class_2561 confirmText() {
        if (this.ticksRemaining <= 0) {
            return class_2561.method_43470("I know what I'm doing!");
        }

        int seconds = (this.ticksRemaining + 19) / 20;
        return class_2561.method_43470("I know what I'm doing! (" + seconds + "s)");
    }
}
